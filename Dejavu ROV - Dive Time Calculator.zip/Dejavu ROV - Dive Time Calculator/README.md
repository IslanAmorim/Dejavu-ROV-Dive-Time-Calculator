# ROVcalc 

  ROV Calculadora de Tempo de Mergulho - created for ROV Team offshore to use during daily activities to calculate duration of Dive.
  This app can be used to calculate any duration betweeen two dates and times. Created using JS/HTML/CSS.
  
## Usage

Enter start time and date and end time and date. Click on calculate or on thruster icon to get calculated duration.

## Questions

For any questions use contacts below:  
        :construction_worker: Developer: Islan Amorim Bezerra  
        :email: Email: [iab@ecomp.poli.br] 
        
 